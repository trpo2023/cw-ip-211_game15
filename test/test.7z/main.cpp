#define CTEST_MAIN

#include "../thirdparty/ctest.h"

int main(int argc, const char** argv)
{
    return ctest_main(argc, argv);
}